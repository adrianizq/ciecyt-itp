/**
 * MapStruct mappers for mapping domain objects and Data Transfer Objects.
 */
package co.edu.itp.ciecyt.service.mapper;
