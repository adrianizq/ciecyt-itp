/**
 * 
 */
/**
 * @author jltovarg
 *
 */
package co.edu.itp.ciecyt.web.rest.model;