/**
 * Service layer beans.
 */
package co.edu.itp.ciecyt.service;
