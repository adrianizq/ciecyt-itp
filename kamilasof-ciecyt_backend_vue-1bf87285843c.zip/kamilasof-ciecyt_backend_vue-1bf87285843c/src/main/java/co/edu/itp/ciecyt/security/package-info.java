/**
 * Spring Security configuration.
 */
package co.edu.itp.ciecyt.security;
