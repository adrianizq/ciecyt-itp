package co.edu.itp.ciecyt.domain.enumeration;

/**
 * The EnumRespuestas enumeration.
 */
public enum EnumRespuestas {
    CUMPLE, NO_CUMPLE, NO_APLICA, SI, NO
}
