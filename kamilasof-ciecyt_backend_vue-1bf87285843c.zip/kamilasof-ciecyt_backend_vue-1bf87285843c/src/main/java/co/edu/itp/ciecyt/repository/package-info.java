/**
 * Spring Data JPA repositories.
 */
package co.edu.itp.ciecyt.repository;
