package co.edu.itp.ciecyt.domain.enumeration;

/**
 * The genero enumeration.
 */
public enum EnumGenero {
    MASCULINO, FEMENINO, OTRO
}
