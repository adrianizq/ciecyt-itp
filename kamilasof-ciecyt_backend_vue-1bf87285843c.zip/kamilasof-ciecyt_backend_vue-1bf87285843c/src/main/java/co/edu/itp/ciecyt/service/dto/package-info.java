/**
 * Data Transfer Objects.
 */
package co.edu.itp.ciecyt.service.dto;
