package co.edu.itp.ciecyt.domain.enumeration;

/**
 * The EnumViabilidad enumeration.
 */
public enum EnumViabilidad {
    VIABLE, PENDIENTE, NO_VIABLE
}
