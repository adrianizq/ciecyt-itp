/**
 * JPA domain objects.
 */
package co.edu.itp.ciecyt.domain;
